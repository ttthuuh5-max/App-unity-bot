from flask import Flask, request, jsonify
import threading
import subprocess
import sys
import os
import tempfile
import queue

app = Flask(__name__)

log_queue = queue.Queue()
bot_process = None
bot_thread = None

def run_bot(code, token):
    global bot_process
    tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8')
    full_code = f"import os\nos.environ['BOT_TOKEN'] = '{token}'\n" + code
    tmp.write(full_code)
    tmp.close()

    bot_process = subprocess.Popen(
        [sys.executable, tmp.name],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1
    )

    for line in bot_process.stdout:
        log_queue.put("[BOT] " + line.rstrip())

    log_queue.put("[SYS] Bot process ended.")
    os.unlink(tmp.name)

@app.route('/run', methods=['POST'])
def run():
    global bot_thread, bot_process
    data = request.json
    code = data.get('code', '')
    token = data.get('token', '')

    if bot_process and bot_process.poll() is None:
        bot_process.terminate()

    bot_thread = threading.Thread(target=run_bot, args=(code, token), daemon=True)
    bot_thread.start()
    return jsonify({'status': 'started'})

@app.route('/stop', methods=['POST'])
def stop():
    global bot_process
    if bot_process and bot_process.poll() is None:
        bot_process.terminate()
        log_queue.put("[SYS] Bot terminated by user.")
    return jsonify({'status': 'stopped'})

@app.route('/logs', methods=['GET'])
def logs():
    lines = []
    while not log_queue.empty():
        lines.append(log_queue.get_nowait())
    return '\n'.join(lines)

if __name__ == '__main__':
    print("[SYS] Bot server running on 127.0.0.1:5000")
    app.run(host='127.0.0.1', port=5000)
