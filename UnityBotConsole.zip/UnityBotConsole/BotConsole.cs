using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using System.Text;

public class BotConsole : MonoBehaviour
{
    private string SERVER_URL = "http://127.0.0.1:5000";

    private List<string> logs = new List<string>();
    private string codeInput = "";
    private string botTokenInput = "";
    private Vector2 scrollPos;
    private bool isRunning = false;
    private bool isPolling = false;
    private Coroutine pollCoroutine;

    private GUIStyle logStyle;
    private GUIStyle inputStyle;
    private GUIStyle btnStyle;
    private GUIStyle headerStyle;
    private bool stylesInit = false;

    void Start()
    {
        Log("[SYS] BotConsole ready.");
        Log("[SYS] Enter bot token and code, then press RUN.");
    }

    void InitStyles()
    {
        if (stylesInit) return;

        logStyle = new GUIStyle(GUI.skin.label);
        logStyle.fontSize = 13;
        logStyle.normal.textColor = new Color(0.2f, 1f, 0.3f);
        logStyle.wordWrap = true;
        logStyle.richText = true;

        inputStyle = new GUIStyle(GUI.skin.textArea);
        inputStyle.fontSize = 13;
        inputStyle.normal.textColor = Color.white;
        inputStyle.normal.background = MakeTex(2, 2, new Color(0.1f, 0.1f, 0.12f));

        btnStyle = new GUIStyle(GUI.skin.button);
        btnStyle.fontSize = 14;
        btnStyle.fontStyle = FontStyle.Bold;
        btnStyle.normal.textColor = Color.white;

        headerStyle = new GUIStyle(GUI.skin.label);
        headerStyle.fontSize = 15;
        headerStyle.fontStyle = FontStyle.Bold;
        headerStyle.normal.textColor = new Color(0.4f, 0.8f, 1f);

        stylesInit = true;
    }

    void OnGUI()
    {
        InitStyles();

        GUI.color = new Color(0.08f, 0.08f, 0.1f);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = Color.white;

        float pad = 16f;
        float w = Screen.width - pad * 2;
        float y = pad;

        GUI.Label(new Rect(pad, y, w, 24), "BOT CONSOLE", headerStyle);
        y += 30;

        GUI.Label(new Rect(pad, y, 80, 20), "Token:", logStyle);
        botTokenInput = GUI.TextField(new Rect(pad + 84, y, w - 84, 24), botTokenInput, inputStyle);
        y += 32;

        GUI.Label(new Rect(pad, y, w, 20), "Code:", logStyle);
        y += 22;

        float codeH = Screen.height * 0.28f;
        codeInput = GUI.TextArea(new Rect(pad, y, w, codeH), codeInput, inputStyle);
        y += codeH + 8;

        float btnW = (w - 8) / 2f;

        if (!isRunning)
        {
            if (GUI.Button(new Rect(pad, y, btnW, 36), "RUN", btnStyle))
            {
                StartBot();
            }
        }
        else
        {
            GUI.color = new Color(1f, 0.3f, 0.3f);
            if (GUI.Button(new Rect(pad, y, btnW, 36), "STOP", btnStyle))
            {
                StopBot();
            }
            GUI.color = Color.white;
        }

        if (GUI.Button(new Rect(pad + btnW + 8, y, btnW, 36), "CLEAR LOG", btnStyle))
        {
            logs.Clear();
        }
        y += 44;

        string status = isRunning ? "<color=#44ff44>RUNNING</color>" : "<color=#888888>STOPPED</color>";
        GUI.Label(new Rect(pad, y, w, 20), "Status: " + status, logStyle);
        y += 24;

        float logH = Screen.height - y - pad;
        GUI.color = new Color(0.06f, 0.06f, 0.08f);
        GUI.DrawTexture(new Rect(pad, y, w, logH), Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUILayout.BeginArea(new Rect(pad + 4, y + 4, w - 8, logH - 8));
        scrollPos = GUILayout.BeginScrollView(scrollPos);
        foreach (var line in logs)
        {
            GUILayout.Label(line, logStyle);
        }
        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }

    void StartBot()
    {
        if (string.IsNullOrEmpty(botTokenInput.Trim()))
        {
            Log("[ERR] Token is empty.");
            return;
        }
        if (string.IsNullOrEmpty(codeInput.Trim()))
        {
            Log("[ERR] Code is empty.");
            return;
        }

        isRunning = true;
        Log("[SYS] Starting bot...");
        StartCoroutine(SendCodeToServer(codeInput, botTokenInput));
    }

    void StopBot()
    {
        isRunning = false;
        isPolling = false;
        if (pollCoroutine != null) StopCoroutine(pollCoroutine);
        Log("[SYS] Bot stopped.");
        StartCoroutine(PostStop());
    }

    IEnumerator PostStop()
    {
        var req = new UnityWebRequest(SERVER_URL + "/stop", "POST");
        req.downloadHandler = new DownloadHandlerBuffer();
        yield return req.SendWebRequest();
    }

    IEnumerator SendCodeToServer(string code, string token)
    {
        string json = "{\"code\":" + JsonEscape(code) + ",\"token\":" + JsonEscape(token) + "}";
        byte[] body = Encoding.UTF8.GetBytes(json);

        var req = new UnityWebRequest(SERVER_URL + "/run", "POST");
        req.uploadHandler = new UploadHandlerRaw(body);
        req.downloadHandler = new DownloadHandlerBuffer();
        req.SetRequestHeader("Content-Type", "application/json");

        yield return req.SendWebRequest();

        if (req.result != UnityWebRequest.Result.Success)
        {
            Log("[ERR] Server unreachable: " + req.error);
            Log("[INFO] Make sure bot_server.py is running on 127.0.0.1:5000");
            isRunning = false;
            yield break;
        }

        Log("[SYS] Code sent. Polling logs...");
        isPolling = true;
        pollCoroutine = StartCoroutine(PollLogs());
    }

    IEnumerator PollLogs()
    {
        while (isPolling)
        {
            var req = UnityWebRequest.Get(SERVER_URL + "/logs");
            yield return req.SendWebRequest();

            if (req.result == UnityWebRequest.Result.Success)
            {
                string raw = req.downloadHandler.text;
                if (!string.IsNullOrEmpty(raw))
                {
                    string[] lines = raw.Split('\n');
                    foreach (var line in lines)
                    {
                        if (!string.IsNullOrEmpty(line.Trim()))
                            Log(line);
                    }
                }
            }

            yield return new WaitForSeconds(1f);
        }
    }

    void Log(string msg)
    {
        string colored = msg;
        if (msg.StartsWith("[ERR]")) colored = "<color=#ff4444>" + msg + "</color>";
        else if (msg.StartsWith("[SYS]")) colored = "<color=#4488ff>" + msg + "</color>";
        else if (msg.StartsWith("[BOT]")) colored = "<color=#44ff88>" + msg + "</color>";
        else if (msg.StartsWith("[INFO]")) colored = "<color=#ffcc44>" + msg + "</color>";

        logs.Add(colored);
        if (logs.Count > 300) logs.RemoveAt(0);
        scrollPos.y = float.MaxValue;
    }

    string JsonEscape(string s)
    {
        return "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t") + "\"";
    }

    Texture2D MakeTex(int w, int h, Color col)
    {
        var tex = new Texture2D(w, h);
        var pixels = tex.GetPixels();
        for (int i = 0; i < pixels.Length; i++) pixels[i] = col;
        tex.SetPixels(pixels);
        tex.Apply();
        return tex;
    }
}
