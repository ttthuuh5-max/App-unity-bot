# BotConsole — Unity + Python

Консоль внутри Unity игры для запуска Telegram ботов.

## Как работает

```
Unity (BotConsole.cs)  <-->  bot_server.py  <-->  твой код бота
```

Unity отправляет код и токен на локальный Flask сервер.
Сервер запускает код как subprocess и стримит логи обратно в Unity.

## Установка

```bash
pip install flask python-telegram-bot>=22.7
```

## Запуск

Сначала сервер:
```bash
python bot_server.py
```

Потом запускай Unity сцену.

## Unity setup

1. Создай пустой GameObject в сцене
2. Прикрепи `BotConsole.cs`
3. Запускай

## Использование

1. Вставь токен бота в поле Token
2. Вставь код бота в поле Code
3. Нажми RUN
4. Логи появляются в консоли снизу
5. STOP — останавливает бота

## Пример кода для вставки

```python
import os
from telegram.ext import ApplicationBuilder, MessageHandler, filters, ContextTypes
from telegram import Update

async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(update.message.text)

app = ApplicationBuilder().token(os.environ['BOT_TOKEN']).build()
app.add_handler(MessageHandler(filters.TEXT, echo))
print("[BOT] Started")
app.run_polling()
```
